/**
 * MathLearn — EdTech Platform Core
 * Auth, roles (student/teacher/admin), navigation, progress, admin CRUD
 */
const App = (function () {
  const KEYS = {
    users: 'ml_users_v2',
    auth: 'ml_auth_v2',
    progress: 'ml_progress_v2',
    questions: 'ml_questions_v2',
    scores: 'ml_scores_v2',
    theme: 'ml_theme',
  };

  const MATERIALS = [
    { id: 'fungsi', title: 'Pengenalan Fungsi', desc: 'Domain, kodomain, range, variabel', section: 'materi-fungsi' },
    { id: 'linear', title: 'Fungsi Linear', desc: 'f(x) = ax + b dan grafiknya', section: 'materi-linear' },
    { id: 'kuadrat', title: 'Fungsi Kuadrat', desc: 'Parabola dan koefisien', section: 'materi-kuadrat' },
    { id: 'komposisi', title: 'Komposisi Fungsi', desc: 'Komposisi 2 & 3 fungsi', section: 'materi-komposisi' },
    { id: 'grafik', title: 'Grafik Fungsi', desc: 'Visualisasi interaktif', section: 'grafik' },
    { id: 'kalkulator', title: 'Kalkulator', desc: 'Hitung nilai & komposisi', section: 'kalkulator' },
    { id: 'latihan', title: 'Latihan Soal', desc: 'Uji pemahaman', section: 'latihan' },
  ];

  const DEMO_USERS = [
    { username: 'siswa', password: '12345', name: 'Siswa Demo', role: 'student', class: 'XII RPL 1', active: true },
    { username: 'guru', password: '12345', name: 'Guru Demo', role: 'teacher', class: '', active: true },
    { username: 'admin', password: '12345', name: 'Admin Demo', role: 'admin', class: '', active: true },
  ];

  // ---------- storage helpers ----------
  function load(key, fallback) {
    try {
      const v = JSON.parse(localStorage.getItem(key));
      return v == null ? fallback : v;
    } catch {
      return fallback;
    }
  }
  function save(key, val) {
    localStorage.setItem(key, JSON.stringify(val));
  }

  function ensureSeed() {
    let users = load(KEYS.users, []);
    if (!users.length) {
      users = DEMO_USERS.map((u) => ({ ...u, createdAt: new Date().toISOString() }));
      save(KEYS.users, users);
    } else {
      // ensure demos exist
      DEMO_USERS.forEach((d) => {
        if (!users.find((u) => u.username === d.username)) {
          users.push({ ...d, createdAt: new Date().toISOString() });
        }
      });
      save(KEYS.users, users);
    }
  }

  function toast(msg, type = 'info') {
    let c = document.querySelector('.toast-container');
    if (!c) {
      c = document.createElement('div');
      c.className = 'toast-container';
      document.body.appendChild(c);
    }
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.textContent = msg;
    c.appendChild(el);
    setTimeout(() => {
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 200);
    }, 2800);
  }

  // ---------- auth ----------
  function currentUser() {
    return load(KEYS.auth, null);
  }
  function isLoggedIn() {
    const a = currentUser();
    return !!(a && a.username);
  }
  function getUsers() {
    return load(KEYS.users, []);
  }

  function login(username, password) {
    const users = getUsers();
    const u = users.find(
      (x) => x.username.toLowerCase() === username.toLowerCase() && x.password === password && x.active !== false
    );
    if (!u) return { ok: false, error: 'Username atau password salah, atau akun nonaktif.' };
    const session = {
      username: u.username,
      name: u.name,
      role: u.role,
      class: u.class || '',
      loginAt: new Date().toISOString(),
    };
    save(KEYS.auth, session);
    return { ok: true, user: session };
  }

  function register({ name, username, password, kelas }) {
    const users = getUsers();
    if (users.find((u) => u.username.toLowerCase() === username.toLowerCase())) {
      return { ok: false, error: 'Username sudah digunakan.' };
    }
    users.push({
      username: username.toLowerCase(),
      password,
      name,
      role: 'student',
      class: kelas || '',
      active: true,
      createdAt: new Date().toISOString(),
    });
    save(KEYS.users, users);
    return { ok: true };
  }

  function logout() {
    localStorage.removeItem(KEYS.auth);
  }

  // ---------- progress (per user) ----------
  function progressKey(username) {
    return username || '_anon';
  }
  function getProgress(username) {
    const all = load(KEYS.progress, {});
    return all[progressKey(username)] || {};
  }
  function setProgress(username, data) {
    const all = load(KEYS.progress, {});
    all[progressKey(username)] = data;
    save(KEYS.progress, all);
  }
  function markMaterialDone(materialId) {
    const u = currentUser();
    if (!u) return;
    const p = getProgress(u.username);
    p[materialId] = true;
    p.lastUpdated = new Date().toISOString();
    setProgress(u.username, p);
    updateProgressUI();
    toast('Materi ditandai selesai', 'success');
  }

  // ---------- scores ----------
  function saveScore(username, score, total) {
    const all = load(KEYS.scores, {});
    if (!all[username]) all[username] = [];
    all[username].push({ score, total, at: new Date().toISOString() });
    save(KEYS.scores, all);
  }
  function getScores(username) {
    const all = load(KEYS.scores, {});
    return all[username] || [];
  }

  // ---------- UI shell ----------
  function showLogin() {
    document.getElementById('login-page').style.display = 'flex';
    document.getElementById('app-container').style.display = 'none';
  }
  function showApp() {
    document.getElementById('login-page').style.display = 'none';
    document.getElementById('app-container').style.display = 'flex';
    applyRoleUI();
  }

  function roleLabel(role) {
    return { student: 'Siswa', teacher: 'Guru', admin: 'Admin' }[role] || role;
  }

  function setAvatarDisplay(container, photoDataUrl, letter) {
    if (!container) return;
    const letterEl = container.querySelector('.avatar-letter');
    const imgEl = container.querySelector('.avatar-img');
    const initial = (letter || 'U').charAt(0).toUpperCase();
    if (letterEl) {
      letterEl.textContent = initial;
      letterEl.style.display = photoDataUrl ? 'none' : 'flex';
    }
    if (imgEl) {
      if (photoDataUrl) {
        imgEl.src = photoDataUrl;
        imgEl.style.display = 'block';
      } else {
        imgEl.removeAttribute('src');
        imgEl.style.display = 'none';
      }
    }
  }

  function getUserPhoto(username) {
    const users = getUsers();
    const row = users.find((x) => x.username === username);
    return row?.photo || null;
  }

  function resizeImageToDataUrl(file, maxSize, maxDim) {
    return new Promise((resolve, reject) => {
      if (!file || !file.type.startsWith('image/')) {
        reject(new Error('File harus berupa gambar.'));
        return;
      }
      if (file.size > 2 * 1024 * 1024) {
        reject(new Error('Ukuran file maksimal 2 MB.'));
        return;
      }
      const reader = new FileReader();
      reader.onerror = () => reject(new Error('Gagal membaca file.'));
      reader.onload = () => {
        const img = new Image();
        img.onerror = () => reject(new Error('Gambar tidak valid.'));
        img.onload = () => {
          let w = img.width;
          let h = img.height;
          const scale = Math.min(1, maxDim / Math.max(w, h));
          w = Math.round(w * scale);
          h = Math.round(h * scale);
          const canvas = document.createElement('canvas');
          canvas.width = w;
          canvas.height = h;
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, w, h);
          let quality = 0.85;
          let dataUrl = canvas.toDataURL('image/jpeg', quality);
          while (dataUrl.length > maxSize && quality > 0.4) {
            quality -= 0.1;
            dataUrl = canvas.toDataURL('image/jpeg', quality);
          }
          if (dataUrl.length > maxSize * 1.5) {
            reject(new Error('Gambar masih terlalu besar setelah diperkecil.'));
            return;
          }
          resolve(dataUrl);
        };
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    });
  }

  function applyRoleUI() {
    const u = currentUser();
    if (!u) return;
    const nameEl = document.getElementById('sidebar-user-name');
    const roleEl = document.getElementById('sidebar-user-role');
    const avEl = document.getElementById('sidebar-user-avatar');
    if (nameEl) nameEl.textContent = u.name || u.username;
    if (roleEl) roleEl.textContent = roleLabel(u.role);
    setAvatarDisplay(avEl, getUserPhoto(u.username) || u.photo, u.name || u.username);

    document.querySelectorAll('[data-role]').forEach((el) => {
      const roles = el.getAttribute('data-role').split(',');
      el.style.display = roles.includes(u.role) ? '' : 'none';
    });

    const dash =
      u.role === 'admin' ? 'dash-admin' : u.role === 'teacher' ? 'dash-teacher' : 'dash-student';
    navigateTo(dash);
    updateGreeting();
    updateProgressUI();
    if (u.role === 'admin') renderAdminUsers();
    if (u.role === 'teacher' || u.role === 'admin') renderTeacherStats();
  }

  function navigateTo(sectionId) {
    document.querySelectorAll('.section').forEach((s) => s.classList.remove('active'));
    const target = document.getElementById(sectionId);
    if (target) target.classList.add('active');

    document.querySelectorAll('.nav-link').forEach((link) => {
      link.classList.remove('active');
      if (link.getAttribute('data-section') === sectionId) link.classList.add('active');
    });

    const titles = {
      'dash-student': 'Dashboard Siswa',
      'dash-teacher': 'Dashboard Guru',
      'dash-admin': 'Dashboard Admin',
      'materi-fungsi': 'Pengenalan Fungsi',
      'materi-linear': 'Fungsi Linear',
      'materi-kuadrat': 'Fungsi Kuadrat',
      'materi-komposisi': 'Komposisi Fungsi',
      grafik: 'Grafik Fungsi',
      kalkulator: 'Kalkulator Fungsi',
      latihan: 'Latihan Soal',
      profil: 'Profil',
      'admin-users': 'Kelola Pengguna',
      'admin-scores': 'Hasil & Laporan',
      tentang: 'Tentang',
    };
    const t = document.getElementById('page-title');
    if (t) t.textContent = titles[sectionId] || 'MathLearn';

    // close mobile sidebar
    document.getElementById('sidebar')?.classList.remove('open');
    document.getElementById('sidebar-overlay')?.classList.remove('show');
    window.scrollTo(0, 0);

    if (sectionId === 'dash-student') renderStudentDash();
    if (sectionId === 'dash-teacher') renderTeacherStats();
    if (sectionId === 'dash-admin') {
      renderAdminUsers();
      renderAdminStats();
    }
    if (sectionId === 'admin-users') renderAdminUsers();
    if (sectionId === 'admin-scores') renderScoresReport();
    if (sectionId === 'profil') renderProfile();
  }

  function updateGreeting() {
    const el = document.getElementById('student-greeting');
    if (!el) return;
    const h = new Date().getHours();
    let g = 'Selamat datang';
    if (h >= 5 && h < 11) g = 'Selamat pagi';
    else if (h >= 11 && h < 15) g = 'Selamat siang';
    else if (h >= 15 && h < 18) g = 'Selamat sore';
    else g = 'Selamat malam';
    const u = currentUser();
    el.textContent = `${g}, ${u?.name || u?.username || 'Siswa'}!`;
  }

  function updateProgressUI() {
    const u = currentUser();
    if (!u) return;
    const p = getProgress(u.username);
    const ids = MATERIALS.map((m) => m.id);
    const done = ids.filter((id) => p[id]).length;
    const pct = Math.round((done / ids.length) * 100);
    const bar = document.getElementById('sidebar-progress-bar');
    const txt = document.getElementById('sidebar-progress-text');
    if (bar) bar.style.width = pct + '%';
    if (txt) txt.textContent = `${done}/${ids.length} materi (${pct}%)`;

    document.querySelectorAll('.mark-complete').forEach((btn) => {
      const mid = btn.getAttribute('data-material');
      if (p[mid]) {
        btn.textContent = '✓ Selesai';
        btn.disabled = true;
        btn.classList.add('completed');
      }
    });
  }

  function renderStudentDash() {
    const u = currentUser();
    if (!u) return;
    const p = getProgress(u.username);
    const ids = MATERIALS.map((m) => m.id);
    const done = ids.filter((id) => p[id]).length;
    const scores = getScores(u.username);
    const last = scores[scores.length - 1];

    const elDone = document.getElementById('stat-materi-done');
    const elPct = document.getElementById('stat-progress-pct');
    const elScore = document.getElementById('stat-last-score');
    const elAct = document.getElementById('stat-activity');
    if (elDone) elDone.textContent = done;
    if (elPct) elPct.textContent = Math.round((done / ids.length) * 100) + '%';
    if (elScore) elScore.textContent = last ? `${last.score}/${last.total}` : '—';
    if (elAct) elAct.textContent = scores.length;

    const grid = document.getElementById('student-materi-grid');
    if (grid) {
      grid.innerHTML = MATERIALS.map((m) => {
        const isDone = !!p[m.id];
        return `<div class="mat-card" data-section="${m.section}" onclick="App.navigateTo('${m.section}')">
          <div class="mat-icon">📘</div>
          <h3>${m.title}</h3>
          <p>${m.desc}</p>
          <span class="mat-status ${isDone ? 'done' : 'todo'}">${isDone ? 'Selesai' : 'Belum'}</span>
        </div>`;
      }).join('');
    }
  }

  function renderTeacherStats() {
    const users = getUsers().filter((u) => u.role === 'student');
    const scores = load(KEYS.scores, {});
    let totalAttempts = 0;
    let totalScore = 0;
    let count = 0;
    Object.values(scores).forEach((arr) => {
      arr.forEach((s) => {
        totalAttempts++;
        totalScore += s.score / s.total;
        count++;
      });
    });
    const avg = count ? Math.round((totalScore / count) * 100) : 0;
    const set = (id, v) => {
      const el = document.getElementById(id);
      if (el) el.textContent = v;
    };
    set('t-stat-siswa', users.length);
    set('t-stat-materi', MATERIALS.length);
    set('t-stat-attempts', totalAttempts);
    set('t-stat-avg', avg + '%');

    const tbody = document.getElementById('teacher-siswa-body');
    if (tbody) {
      tbody.innerHTML = users
        .map((u) => {
          const p = getProgress(u.username);
          const done = MATERIALS.filter((m) => p[m.id]).length;
          const sc = getScores(u.username);
          const last = sc[sc.length - 1];
          return `<tr>
            <td>${escapeHtml(u.name)}</td>
            <td>${escapeHtml(u.class || '—')}</td>
            <td>${done}/${MATERIALS.length}</td>
            <td>${last ? last.score + '/' + last.total : '—'}</td>
            <td>${sc.length}</td>
          </tr>`;
        })
        .join('') || '<tr><td colspan="5" class="text-center">Belum ada siswa</td></tr>';
    }
  }

  function renderAdminStats() {
    const users = getUsers();
    const set = (id, v) => {
      const el = document.getElementById(id);
      if (el) el.textContent = v;
    };
    set('a-stat-users', users.length);
    set('a-stat-siswa', users.filter((u) => u.role === 'student').length);
    set('a-stat-guru', users.filter((u) => u.role === 'teacher').length);
    set('a-stat-admin', users.filter((u) => u.role === 'admin').length);
  }

  function renderAdminUsers() {
    const tbody = document.getElementById('admin-users-body');
    if (!tbody) return;
    const users = getUsers();
    const me = currentUser();
    tbody.innerHTML = users
      .map((u) => {
        const badge =
          u.role === 'admin'
            ? 'badge-admin'
            : u.role === 'teacher'
              ? 'badge-teacher'
              : 'badge-student';
        return `<tr>
          <td>${escapeHtml(u.name)}</td>
          <td>${escapeHtml(u.username)}</td>
          <td><span class="badge ${badge}">${roleLabel(u.role)}</span></td>
          <td>${escapeHtml(u.class || '—')}</td>
          <td>${u.active === false ? '<span class="badge badge-admin">Nonaktif</span>' : '<span class="badge badge-done">Aktif</span>'}</td>
          <td>
            <select class="role-select" data-user="${escapeHtml(u.username)}" ${u.username === me?.username ? 'disabled' : ''} style="padding:4px 8px;border-radius:6px;border:1px solid var(--border);font-size:0.8rem;">
              <option value="student" ${u.role === 'student' ? 'selected' : ''}>Siswa</option>
              <option value="teacher" ${u.role === 'teacher' ? 'selected' : ''}>Guru</option>
              <option value="admin" ${u.role === 'admin' ? 'selected' : ''}>Admin</option>
            </select>
            <button class="btn btn-sm btn-secondary toggle-active" data-user="${escapeHtml(u.username)}" ${u.username === me?.username ? 'disabled' : ''}>${u.active === false ? 'Aktifkan' : 'Nonaktifkan'}</button>
          </td>
        </tr>`;
      })
      .join('');

    tbody.querySelectorAll('.role-select').forEach((sel) => {
      sel.addEventListener('change', () => {
        changeUserRole(sel.getAttribute('data-user'), sel.value);
      });
    });
    tbody.querySelectorAll('.toggle-active').forEach((btn) => {
      btn.addEventListener('click', () => toggleUserActive(btn.getAttribute('data-user')));
    });
  }

  function changeUserRole(username, role) {
    const users = getUsers();
    const u = users.find((x) => x.username === username);
    if (!u) return;
    u.role = role;
    save(KEYS.users, users);
    toast(`Role ${username} diubah ke ${roleLabel(role)}`, 'success');
    renderAdminUsers();
    renderAdminStats();
  }

  function toggleUserActive(username) {
    const users = getUsers();
    const u = users.find((x) => x.username === username);
    if (!u) return;
    u.active = u.active === false ? true : false;
    save(KEYS.users, users);
    toast(`Akun ${username} ${u.active ? 'diaktifkan' : 'dinonaktifkan'}`, 'info');
    renderAdminUsers();
  }

  function renderScoresReport() {
    const tbody = document.getElementById('scores-report-body');
    if (!tbody) return;
    const users = getUsers().filter((u) => u.role === 'student');
    const rows = [];
    users.forEach((u) => {
      const sc = getScores(u.username);
      if (!sc.length) {
        rows.push(`<tr><td>${escapeHtml(u.name)}</td><td>${escapeHtml(u.class || '—')}</td><td>—</td><td>—</td><td>0</td></tr>`);
      } else {
        const last = sc[sc.length - 1];
        const best = sc.reduce((a, b) => (a.score / a.total >= b.score / b.total ? a : b));
        rows.push(
          `<tr><td>${escapeHtml(u.name)}</td><td>${escapeHtml(u.class || '—')}</td><td>${last.score}/${last.total}</td><td>${best.score}/${best.total}</td><td>${sc.length}</td></tr>`
        );
      }
    });
    tbody.innerHTML = rows.join('') || '<tr><td colspan="5" class="text-center">Belum ada data</td></tr>';
  }

  function renderProfile() {
    const u = currentUser();
    if (!u) return;
    const nameIn = document.getElementById('profile-name');
    const classIn = document.getElementById('profile-class');
    if (nameIn) nameIn.value = u.name || '';
    if (classIn) classIn.value = u.class || '';
    const photo = getUserPhoto(u.username);
    setAvatarDisplay(document.getElementById('profile-photo-wrap'), photo, u.name || u.username);
    const p = getProgress(u.username);
    const list = document.getElementById('profile-progress-list');
    if (list) {
      list.innerHTML = MATERIALS.map((m) => {
        const done = !!p[m.id];
        return `<div style="display:flex;justify-content:space-between;padding:10px 12px;background:var(--bg);border-radius:8px;border:1px solid var(--border);margin-bottom:6px;">
          <span>${m.title}</span>
          <span style="font-weight:600;color:${done ? 'var(--success)' : 'var(--text-3)'}">${done ? '✓ Selesai' : 'Belum'}</span>
        </div>`;
      }).join('');
    }
  }

  function escapeHtml(s) {
    return String(s || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // ---------- init ----------
  function init() {
    ensureSeed();

    // theme
    if (localStorage.getItem(KEYS.theme) === 'dark') {
      document.body.classList.add('dark-theme');
    }

    // auth forms
    document.getElementById('login-form')?.addEventListener('submit', (e) => {
      e.preventDefault();
      const username = document.getElementById('login-username').value.trim();
      const password = document.getElementById('login-password').value;
      const err = document.getElementById('login-error');
      if (!username || !password) {
        if (err) {
          err.textContent = 'Username dan password wajib diisi.';
          err.style.display = 'block';
        }
        return;
      }
      const res = login(username, password);
      if (!res.ok) {
        if (err) {
          err.textContent = res.error;
          err.style.display = 'block';
        }
        return;
      }
      if (err) err.style.display = 'none';
      showApp();
      toast(`Selamat datang, ${res.user.name}!`, 'success');
    });

    document.getElementById('register-form')?.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('reg-name').value.trim();
      const username = document.getElementById('reg-username').value.trim();
      const password = document.getElementById('reg-password').value;
      const password2 = document.getElementById('reg-password2').value;
      const kelas = document.getElementById('reg-class').value.trim();
      const err = document.getElementById('register-error');
      const ok = document.getElementById('register-success');
      if (ok) ok.style.display = 'none';
      if (!name || !username || !password) {
        if (err) {
          err.textContent = 'Lengkapi semua field wajib.';
          err.style.display = 'block';
        }
        return;
      }
      if (username.length < 3) {
        if (err) {
          err.textContent = 'Username minimal 3 karakter.';
          err.style.display = 'block';
        }
        return;
      }
      if (password.length < 4) {
        if (err) {
          err.textContent = 'Password minimal 4 karakter.';
          err.style.display = 'block';
        }
        return;
      }
      if (password !== password2) {
        if (err) {
          err.textContent = 'Konfirmasi password tidak cocok.';
          err.style.display = 'block';
        }
        return;
      }
      const res = register({ name, username, password, kelas });
      if (!res.ok) {
        if (err) {
          err.textContent = res.error;
          err.style.display = 'block';
        }
        return;
      }
      if (err) err.style.display = 'none';
      if (ok) {
        ok.textContent = 'Registrasi berhasil! Silakan masuk.';
        ok.style.display = 'block';
      }
      toast('Akun berhasil dibuat', 'success');
      setTimeout(() => {
        document.querySelector('.auth-tab[data-tab="login"]')?.click();
        document.getElementById('login-username').value = username.toLowerCase();
      }, 1000);
    });

    // auth tabs
    document.querySelectorAll('.auth-tab').forEach((tab) => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.auth-tab').forEach((t) => t.classList.remove('active'));
        tab.classList.add('active');
        const mode = tab.getAttribute('data-tab');
        document.getElementById('login-form').style.display = mode === 'login' ? 'block' : 'none';
        document.getElementById('register-form').style.display = mode === 'register' ? 'block' : 'none';
      });
    });

    // password toggles
    document.querySelectorAll('.pwd-toggle').forEach((btn) => {
      btn.addEventListener('click', () => {
        const input = btn.parentElement.querySelector('input');
        if (!input) return;
        input.type = input.type === 'password' ? 'text' : 'password';
        btn.textContent = input.type === 'password' ? 'Tampil' : 'Sembunyi';
      });
    });

    document.getElementById('logout-btn')?.addEventListener('click', () => {
      if (!confirm('Yakin ingin keluar?')) return;
      logout();
      showLogin();
      toast('Berhasil keluar', 'info');
    });

    document.getElementById('theme-toggle')?.addEventListener('click', () => {
      document.body.classList.toggle('dark-theme');
      localStorage.setItem(KEYS.theme, document.body.classList.contains('dark-theme') ? 'dark' : 'light');
    });

    // sidebar
    document.getElementById('menu-toggle')?.addEventListener('click', () => {
      document.getElementById('sidebar')?.classList.toggle('open');
      document.getElementById('sidebar-overlay')?.classList.toggle('show');
    });
    document.getElementById('sidebar-overlay')?.addEventListener('click', () => {
      document.getElementById('sidebar')?.classList.remove('open');
      document.getElementById('sidebar-overlay')?.classList.remove('show');
    });

    // nav
    document.querySelectorAll('[data-section]').forEach((el) => {
      el.addEventListener('click', (e) => {
        e.preventDefault();
        const sec = el.getAttribute('data-section');
        if (sec) navigateTo(sec);
      });
    });

    // mark complete
    document.querySelectorAll('.mark-complete').forEach((btn) => {
      btn.addEventListener('click', () => {
        const mid = btn.getAttribute('data-material');
        if (mid) {
          markMaterialDone(mid);
          btn.textContent = '✓ Selesai';
          btn.disabled = true;
          btn.classList.add('completed');
        }
      });
    });

    // profile save (nama + kelas; foto sudah tersimpan saat dipilih)
    document.getElementById('profile-save')?.addEventListener('click', () => {
      const u = currentUser();
      if (!u) return;
      const name = document.getElementById('profile-name')?.value.trim() || u.name;
      const kelas = document.getElementById('profile-class')?.value.trim() || '';
      const users = getUsers();
      const row = users.find((x) => x.username === u.username);
      if (row) {
        row.name = name;
        row.class = kelas;
        save(KEYS.users, users);
      }
      u.name = name;
      u.class = kelas;
      save(KEYS.auth, u);
      const nameEl = document.getElementById('sidebar-user-name');
      if (nameEl) nameEl.textContent = name;
      setAvatarDisplay(
        document.getElementById('sidebar-user-avatar'),
        getUserPhoto(u.username),
        name
      );
      setAvatarDisplay(document.getElementById('profile-photo-wrap'), getUserPhoto(u.username), name);
      toast('Profil disimpan', 'success');
    });

    // foto profil
    const photoInput = document.getElementById('profile-photo-input');
    document.getElementById('profile-photo-pick')?.addEventListener('click', () => photoInput?.click());
    photoInput?.addEventListener('change', async () => {
      const file = photoInput.files && photoInput.files[0];
      photoInput.value = '';
      if (!file) return;
      const u = currentUser();
      if (!u) return;
      try {
        const dataUrl = await resizeImageToDataUrl(file, 180000, 320);
        const users = getUsers();
        const row = users.find((x) => x.username === u.username);
        if (row) {
          row.photo = dataUrl;
          save(KEYS.users, users);
        }
        u.photo = dataUrl;
        save(KEYS.auth, u);
        setAvatarDisplay(document.getElementById('profile-photo-wrap'), dataUrl, u.name || u.username);
        setAvatarDisplay(document.getElementById('sidebar-user-avatar'), dataUrl, u.name || u.username);
        toast('Foto profil diperbarui', 'success');
      } catch (err) {
        toast(err.message || 'Gagal mengunggah foto', 'error');
      }
    });
    document.getElementById('profile-photo-remove')?.addEventListener('click', () => {
      const u = currentUser();
      if (!u) return;
      if (!getUserPhoto(u.username)) {
        toast('Belum ada foto profil', 'info');
        return;
      }
      if (!confirm('Hapus foto profil?')) return;
      const users = getUsers();
      const row = users.find((x) => x.username === u.username);
      if (row) {
        delete row.photo;
        save(KEYS.users, users);
      }
      delete u.photo;
      save(KEYS.auth, u);
      setAvatarDisplay(document.getElementById('profile-photo-wrap'), null, u.name || u.username);
      setAvatarDisplay(document.getElementById('sidebar-user-avatar'), null, u.name || u.username);
      toast('Foto profil dihapus', 'info');
    });

    document.getElementById('profile-reset-progress')?.addEventListener('click', () => {
      const u = currentUser();
      if (!u || !confirm('Reset semua progress belajar?')) return;
      setProgress(u.username, {});
      document.querySelectorAll('.mark-complete').forEach((btn) => {
        btn.disabled = false;
        btn.classList.remove('completed');
        btn.textContent = 'Tandai Selesai';
      });
      updateProgressUI();
      renderProfile();
      toast('Progress direset', 'info');
    });

    // expose score saver for exercises
    window.MathLearnSaveScore = function (score, total) {
      const u = currentUser();
      if (u) saveScore(u.username, score, total);
    };

    // modules
    if (window.Calculator) Calculator.init();
    if (window.GraphModule) GraphModule.init();
    if (window.Exercises) {
      Exercises.init();
      // hook score on result if possible
      const orig = Exercises;
    }

    if (isLoggedIn()) {
      showApp();
    } else {
      showLogin();
    }
  }

  document.addEventListener('DOMContentLoaded', init);

  return {
    navigateTo,
    markMaterialDone,
    currentUser,
    toast,
  };
})();
