/**
 * MathLearn - Calculator Module
 * Kalkulator fungsi interaktif
 */

const Calculator = (function() {
    const { DEFAULT_FUNCTIONS, compose, composeThree, composeAlgebraic, formatLinearExpression } = window.MathFunctions;

    let currentF = { ...DEFAULT_FUNCTIONS.f, name: 'f' };
    let currentG = { ...DEFAULT_FUNCTIONS.g, name: 'g' };
    let currentH = { ...DEFAULT_FUNCTIONS.h, name: 'h' };

    function init() {
        // Bind events
        const calcBtn = document.getElementById('calc-compute');
        const resetBtn = document.getElementById('calc-reset');
        const modeSelect = document.getElementById('calc-mode');
        
        if (calcBtn) calcBtn.addEventListener('click', compute);
        if (resetBtn) resetBtn.addEventListener('click', reset);
        if (modeSelect) modeSelect.addEventListener('change', updateUI);
        
        // Coefficient change listeners
        ['f-a', 'f-b', 'g-a', 'g-b', 'h-a', 'h-b'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.addEventListener('change', updateFunctionsFromInputs);
        });
        
        updateUI();
        updateFunctionsFromInputs();
    }

    function updateFunctionsFromInputs() {
        const fa = parseFloat(document.getElementById('f-a')?.value) || 1;
        const fb = parseFloat(document.getElementById('f-b')?.value) || 3;
        const ga = parseFloat(document.getElementById('g-a')?.value) || 4;
        const gb = parseFloat(document.getElementById('g-b')?.value) || 5;
        const ha = parseFloat(document.getElementById('h-a')?.value) || 3;
        const hb = parseFloat(document.getElementById('h-b')?.value) || -9;

        currentF = { name: 'f', a: fa, b: fb, expression: formatLinearExpression(fa, fb), type: 'linear', compute: (x) => fa * x + fb };
        currentG = { name: 'g', a: ga, b: gb, expression: formatLinearExpression(ga, gb), type: 'linear', compute: (x) => ga * x + gb };
        currentH = { name: 'h', a: ha, b: hb, expression: formatLinearExpression(ha, hb), type: 'linear', compute: (x) => ha * x + hb };

        // Update display expressions
        updateExpressionDisplays();
    }

    function updateExpressionDisplays() {
        const displays = {
            'disp-f': `f(x) = ${currentF.expression}`,
            'disp-g': `g(x) = ${currentG.expression}`,
            'disp-h': `h(x) = ${currentH.expression}`
        };
        for (const [id, text] of Object.entries(displays)) {
            const el = document.getElementById(id);
            if (el) el.textContent = text;
        }
    }

    function updateUI() {
        const mode = document.getElementById('calc-mode')?.value || 'single';
        const compositionGroup = document.getElementById('calc-composition-group');
        const compositionSelect = document.getElementById('calc-composition');
        const funcGroup = document.getElementById('calc-func-group');
        
        if (compositionGroup) {
            compositionGroup.style.display = (mode === 'single') ? 'none' : 'block';
        }
        if (funcGroup) {
            funcGroup.style.display = (mode === 'single') ? 'block' : 'none';
        }
        
        // Populate composition options
        if (compositionSelect && mode !== 'single') {
            compositionSelect.innerHTML = '';
            if (mode === 'double') {
                const options = [
                    { v: 'fog', t: '(f ∘ g)(x) = f(g(x))' },
                    { v: 'gof', t: '(g ∘ f)(x) = g(f(x))' },
                    { v: 'foh', t: '(f ∘ h)(x) = f(h(x))' },
                    { v: 'hof', t: '(h ∘ f)(x) = h(f(x))' },
                    { v: 'goh', t: '(g ∘ h)(x) = g(h(x))' },
                    { v: 'hog', t: '(h ∘ g)(x) = h(g(x))' }
                ];
                options.forEach(o => {
                    const opt = document.createElement('option');
                    opt.value = o.v;
                    opt.textContent = o.t;
                    compositionSelect.appendChild(opt);
                });
            } else if (mode === 'triple') {
                const options = [
                    { v: 'fogoh', t: '(f ∘ g ∘ h)(x)' },
                    { v: 'fohog', t: '(f ∘ h ∘ g)(x)' },
                    { v: 'gofoh', t: '(g ∘ f ∘ h)(x)' },
                    { v: 'gohof', t: '(g ∘ h ∘ f)(x)' },
                    { v: 'hofog', t: '(h ∘ f ∘ g)(x)' },
                    { v: 'hogof', t: '(h ∘ g ∘ f)(x)' }
                ];
                options.forEach(o => {
                    const opt = document.createElement('option');
                    opt.value = o.v;
                    opt.textContent = o.t;
                    compositionSelect.appendChild(opt);
                });
            }
        }
    }

    function compute() {
        updateFunctionsFromInputs();
        const mode = document.getElementById('calc-mode')?.value || 'single';
        const xVal = parseFloat(document.getElementById('calc-x')?.value);
        const resultArea = document.getElementById('calc-result');
        const stepsArea = document.getElementById('calc-steps');

        if (isNaN(xVal)) {
            resultArea.innerHTML = '<span class="error">Masukkan nilai x yang valid!</span>';
            stepsArea.innerHTML = '';
            return;
        }

        let result, stepsHtml = '';

        if (mode === 'single') {
            const funcSelect = document.getElementById('calc-func')?.value || 'f';
            let fn;
            if (funcSelect === 'f') fn = currentF;
            else if (funcSelect === 'g') fn = currentG;
            else fn = currentH;

            result = fn.compute(xVal);
            stepsHtml = `
                <div class="step">
                    <strong>Langkah perhitungan:</strong>
                    <p>${fn.name}(x) = ${fn.expression}</p>
                    <p>${fn.name}(${xVal}) = ${fn.a}(${xVal}) + (${fn.b})</p>
                    <p>${fn.name}(${xVal}) = ${fn.a * xVal} + ${fn.b}</p>
                    <p class="result-val">${fn.name}(${xVal}) = <strong>${result}</strong></p>
                </div>
            `;
        } else if (mode === 'double') {
            const comp = document.getElementById('calc-composition')?.value || 'fog';
            let outer, inner, label;
            
            switch (comp) {
                case 'fog': outer = currentF; inner = currentG; label = '(f ∘ g)'; break;
                case 'gof': outer = currentG; inner = currentF; label = '(g ∘ f)'; break;
                case 'foh': outer = currentF; inner = currentH; label = '(f ∘ h)'; break;
                case 'hof': outer = currentH; inner = currentF; label = '(h ∘ f)'; break;
                case 'goh': outer = currentG; inner = currentH; label = '(g ∘ h)'; break;
                case 'hog': outer = currentH; inner = currentG; label = '(h ∘ g)'; break;
                default: outer = currentF; inner = currentG; label = '(f ∘ g)';
            }

            const innerVal = inner.compute(xVal);
            result = outer.compute(innerVal);
            const alg = composeAlgebraic(outer, inner);

            stepsHtml = `
                <div class="step">
                    <strong>Komposisi ${label}(x) = ${outer.name}(${inner.name}(x))</strong>
                    <p><strong>1. Hitung ${inner.name}(${xVal}):</strong></p>
                    <p>${inner.name}(x) = ${inner.expression}</p>
                    <p>${inner.name}(${xVal}) = ${inner.a}(${xVal}) + (${inner.b}) = ${innerVal}</p>
                    <p><strong>2. Hitung ${outer.name}(${innerVal}):</strong></p>
                    <p>${outer.name}(x) = ${outer.expression}</p>
                    <p>${outer.name}(${innerVal}) = ${outer.a}(${innerVal}) + (${outer.b}) = ${result}</p>
                    <p class="result-val">${label}(${xVal}) = <strong>${result}</strong></p>
                </div>
                <div class="step algebraic">
                    <strong>Bentuk aljabar:</strong>
                    <p>${alg ? alg.steps.join('<br>') : ''}</p>
                    <p>Jadi ${label}(x) = ${alg ? alg.expression : ''}</p>
                </div>
            `;
        } else if (mode === 'triple') {
            const comp = document.getElementById('calc-composition')?.value || 'fogoh';
            let outer, mid, inner, label;
            
            switch (comp) {
                case 'fogoh': outer = currentF; mid = currentG; inner = currentH; label = '(f ∘ g ∘ h)'; break;
                case 'fohog': outer = currentF; mid = currentH; inner = currentG; label = '(f ∘ h ∘ g)'; break;
                case 'gofoh': outer = currentG; mid = currentF; inner = currentH; label = '(g ∘ f ∘ h)'; break;
                case 'gohof': outer = currentG; mid = currentH; inner = currentF; label = '(g ∘ h ∘ f)'; break;
                case 'hofog': outer = currentH; mid = currentF; inner = currentG; label = '(h ∘ f ∘ g)'; break;
                case 'hogof': outer = currentH; mid = currentG; inner = currentF; label = '(h ∘ g ∘ f)'; break;
                default: outer = currentF; mid = currentG; inner = currentH; label = '(f ∘ g ∘ h)';
            }

            const innerVal = inner.compute(xVal);
            const midVal = mid.compute(innerVal);
            result = outer.compute(midVal);

            // Algebraic for triple
            const midInnerAlg = composeAlgebraic(mid, inner);
            const fullA = outer.a * midInnerAlg.a;
            const fullB = outer.a * midInnerAlg.b + outer.b;
            const fullExpr = formatLinearExpression(fullA, fullB);

            stepsHtml = `
                <div class="step">
                    <strong>Komposisi ${label}(x) = ${outer.name}(${mid.name}(${inner.name}(x)))</strong>
                    <p><strong>1. Hitung ${inner.name}(${xVal}):</strong></p>
                    <p>${inner.name}(${xVal}) = ${inner.a}(${xVal}) + (${inner.b}) = ${innerVal}</p>
                    <p><strong>2. Hitung ${mid.name}(${innerVal}):</strong></p>
                    <p>${mid.name}(${innerVal}) = ${mid.a}(${innerVal}) + (${mid.b}) = ${midVal}</p>
                    <p><strong>3. Hitung ${outer.name}(${midVal}):</strong></p>
                    <p>${outer.name}(${midVal}) = ${outer.a}(${midVal}) + (${outer.b}) = ${result}</p>
                    <p class="result-val">${label}(${xVal}) = <strong>${result}</strong></p>
                </div>
                <div class="step algebraic">
                    <strong>Bentuk aljabar:</strong>
                    <p>1. ${mid.name}(${inner.name}(x)) = ${midInnerAlg.expression}</p>
                    <p>2. ${outer.name}(${mid.name}(${inner.name}(x))) = ${outer.a}(${midInnerAlg.expression}) + (${outer.b})</p>
                    <p>3. = ${fullExpr}</p>
                    <p>Jadi ${label}(x) = <strong>${fullExpr}</strong></p>
                </div>
            `;
        }

        resultArea.innerHTML = `<div class="final-result">Hasil: <strong>${result}</strong></div>`;
        stepsArea.innerHTML = stepsHtml;
    }

    function reset() {
        document.getElementById('calc-x').value = '';
        document.getElementById('calc-mode').value = 'single';
        document.getElementById('f-a').value = 1;
        document.getElementById('f-b').value = 3;
        document.getElementById('g-a').value = 4;
        document.getElementById('g-b').value = 5;
        document.getElementById('h-a').value = 3;
        document.getElementById('h-b').value = -9;
        document.getElementById('calc-result').innerHTML = '';
        document.getElementById('calc-steps').innerHTML = '';
        updateUI();
        updateFunctionsFromInputs();
    }

    function copyResult() {
        const result = document.querySelector('#calc-result .final-result strong');
        if (result) {
            navigator.clipboard.writeText(result.textContent).then(() => {
                alert('Hasil disalin ke clipboard!');
            });
        }
    }

    return { init, compute, reset, copyResult };
})();

window.Calculator = Calculator;
