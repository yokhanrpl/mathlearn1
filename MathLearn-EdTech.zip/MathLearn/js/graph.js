/**
 * MathLearn - Graph Module
 * Grafik fungsi interaktif menggunakan Chart.js
 */

const GraphModule = (function() {
    const { generateGraphData, formatLinearExpression, formatQuadraticExpression, createLinear, createQuadratic } = window.MathFunctions;

    let chartInstance = null;

    function init() {
        const plotBtn = document.getElementById('graph-plot');
        const resetBtn = document.getElementById('graph-reset');
        const typeSelect = document.getElementById('graph-type');

        if (plotBtn) plotBtn.addEventListener('click', plotGraph);
        if (resetBtn) resetBtn.addEventListener('click', resetGraph);
        if (typeSelect) typeSelect.addEventListener('change', updateGraphInputs);

        updateGraphInputs();
        // Initial plot with default
        setTimeout(() => plotGraph(), 300);
    }

    function updateGraphInputs() {
        const type = document.getElementById('graph-type')?.value || 'linear';
        const linearInputs = document.getElementById('linear-inputs');
        const quadraticInputs = document.getElementById('quadratic-inputs');
        const presetSelect = document.getElementById('graph-preset');

        if (linearInputs) linearInputs.style.display = type === 'linear' ? 'flex' : 'none';
        if (quadraticInputs) quadraticInputs.style.display = type === 'quadratic' ? 'flex' : 'none';

        // Update presets
        if (presetSelect) {
            presetSelect.innerHTML = '';
            if (type === 'linear') {
                const presets = [
                    { v: 'default-f', t: 'f(x) = x + 3' },
                    { v: 'default-g', t: 'g(x) = 4x + 5' },
                    { v: 'default-h', t: 'h(x) = 3x - 9' },
                    { v: 'custom', t: 'Kustom' }
                ];
                presets.forEach(p => {
                    const opt = document.createElement('option');
                    opt.value = p.v;
                    opt.textContent = p.t;
                    presetSelect.appendChild(opt);
                });
            } else {
                const presets = [
                    { v: 'x2', t: 'f(x) = x²' },
                    { v: 'x2-2x-3', t: 'f(x) = x² - 2x - 3' },
                    { v: '-x2+4', t: 'f(x) = -x² + 4' },
                    { v: 'custom', t: 'Kustom' }
                ];
                presets.forEach(p => {
                    const opt = document.createElement('option');
                    opt.value = p.v;
                    opt.textContent = p.t;
                    presetSelect.appendChild(opt);
                });
            }
            presetSelect.addEventListener('change', applyPreset);
        }
    }

    function applyPreset() {
        const type = document.getElementById('graph-type')?.value || 'linear';
        const preset = document.getElementById('graph-preset')?.value;

        if (type === 'linear') {
            if (preset === 'default-f') {
                document.getElementById('graph-a').value = 1;
                document.getElementById('graph-b').value = 3;
            } else if (preset === 'default-g') {
                document.getElementById('graph-a').value = 4;
                document.getElementById('graph-b').value = 5;
            } else if (preset === 'default-h') {
                document.getElementById('graph-a').value = 3;
                document.getElementById('graph-b').value = -9;
            }
        } else {
            if (preset === 'x2') {
                document.getElementById('graph-qa').value = 1;
                document.getElementById('graph-qb').value = 0;
                document.getElementById('graph-qc').value = 0;
            } else if (preset === 'x2-2x-3') {
                document.getElementById('graph-qa').value = 1;
                document.getElementById('graph-qb').value = -2;
                document.getElementById('graph-qc').value = -3;
            } else if (preset === '-x2+4') {
                document.getElementById('graph-qa').value = -1;
                document.getElementById('graph-qb').value = 0;
                document.getElementById('graph-qc').value = 4;
            }
        }
    }

    function plotGraph() {
        const type = document.getElementById('graph-type')?.value || 'linear';
        const xMin = parseFloat(document.getElementById('graph-xmin')?.value) || -10;
        const xMax = parseFloat(document.getElementById('graph-xmax')?.value) || 10;
        const canvas = document.getElementById('function-chart');
        const infoEl = document.getElementById('graph-info');
        const errorEl = document.getElementById('graph-error');

        if (!canvas) return;

        let computeFn, expression, color;

        if (type === 'linear') {
            const a = parseFloat(document.getElementById('graph-a')?.value);
            const b = parseFloat(document.getElementById('graph-b')?.value);
            if (isNaN(a) || isNaN(b)) {
                showError('Masukkan koefisien a dan b yang valid!');
                return;
            }
            computeFn = (x) => a * x + b;
            expression = `f(x) = ${formatLinearExpression(a, b)}`;
            color = '#3b82f6';
        } else {
            const a = parseFloat(document.getElementById('graph-qa')?.value);
            const b = parseFloat(document.getElementById('graph-qb')?.value);
            const c = parseFloat(document.getElementById('graph-qc')?.value);
            if (isNaN(a) || isNaN(b) || isNaN(c)) {
                showError('Masukkan koefisien a, b, dan c yang valid!');
                return;
            }
            if (a === 0) {
                showError('Untuk fungsi kuadrat, koefisien a tidak boleh 0!');
                return;
            }
            computeFn = (x) => a * x * x + b * x + c;
            expression = `f(x) = ${formatQuadraticExpression(a, b, c)}`;
            color = '#10b981';
        }

        if (xMin >= xMax) {
            showError('Nilai x minimum harus lebih kecil dari x maksimum!');
            return;
        }

        hideError();

        const dataPoints = generateGraphData(computeFn, xMin, xMax, 200);

        // Destroy previous chart
        if (chartInstance) {
            chartInstance.destroy();
        }

        const ctx = canvas.getContext('2d');
        chartInstance = new Chart(ctx, {
            type: 'line',
            data: {
                datasets: [{
                    label: expression,
                    data: dataPoints,
                    borderColor: color,
                    backgroundColor: color + '20',
                    borderWidth: 2.5,
                    pointRadius: 0,
                    pointHoverRadius: 5,
                    tension: 0.1,
                    fill: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                        labels: {
                            font: { size: 14, weight: '600' },
                            color: '#1e293b'
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `y = ${context.parsed.y.toFixed(4)}`;
                            },
                            title: function(context) {
                                return `x = ${context[0].parsed.x.toFixed(4)}`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        type: 'linear',
                        title: {
                            display: true,
                            text: 'x',
                            font: { size: 14, weight: '600' }
                        },
                        grid: {
                            color: '#e2e8f0'
                        },
                        ticks: {
                            color: '#64748b'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'y',
                            font: { size: 14, weight: '600' }
                        },
                        grid: {
                            color: '#e2e8f0'
                        },
                        ticks: {
                            color: '#64748b'
                        }
                    }
                }
            }
        });

        // Update info
        if (infoEl) {
            // Sample points
            const samples = [-2, -1, 0, 1, 2].map(x => {
                if (x >= xMin && x <= xMax) {
                    return `f(${x}) = ${computeFn(x).toFixed(2)}`;
                }
                return null;
            }).filter(Boolean).join(' | ');

            infoEl.innerHTML = `
                <strong>${expression}</strong><br>
                Rentang x: [${xMin}, ${xMax}]<br>
                Contoh nilai: ${samples}
            `;
        }
    }

    function resetGraph() {
        document.getElementById('graph-type').value = 'linear';
        document.getElementById('graph-a').value = 1;
        document.getElementById('graph-b').value = 3;
        document.getElementById('graph-qa').value = 1;
        document.getElementById('graph-qb').value = 0;
        document.getElementById('graph-qc').value = 0;
        document.getElementById('graph-xmin').value = -10;
        document.getElementById('graph-xmax').value = 10;
        updateGraphInputs();
        plotGraph();
    }

    function showError(msg) {
        const errorEl = document.getElementById('graph-error');
        if (errorEl) {
            errorEl.textContent = msg;
            errorEl.style.display = 'block';
        }
    }

    function hideError() {
        const errorEl = document.getElementById('graph-error');
        if (errorEl) {
            errorEl.style.display = 'none';
        }
    }

    return { init, plotGraph, resetGraph };
})();

window.GraphModule = GraphModule;
