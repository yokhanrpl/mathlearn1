/**
 * MathLearn - Exercises Module
 * Latihan soal interaktif
 */

const Exercises = (function() {
    const questions = [
        // Mudah - Pengertian
        {
            id: 1,
            level: 'mudah',
            type: 'mc',
            question: 'Apa yang dimaksud dengan fungsi dalam matematika?',
            options: [
                'Relasi yang memasangkan setiap anggota domain dengan tepat satu anggota kodomain',
                'Relasi yang memasangkan satu anggota domain dengan banyak anggota kodomain',
                'Himpunan semua bilangan real',
                'Persamaan yang selalu bernilai nol'
            ],
            correct: 0,
            explanation: 'Fungsi adalah relasi khusus di mana setiap elemen di domain dipasangkan dengan tepat satu elemen di kodomain.'
        },
        {
            id: 2,
            level: 'mudah',
            type: 'mc',
            question: 'Bentuk umum fungsi linear adalah...',
            options: [
                'f(x) = ax² + bx + c',
                'f(x) = ax + b',
                'f(x) = a/x + b',
                'f(x) = √x + a'
            ],
            correct: 1,
            explanation: 'Fungsi linear memiliki bentuk umum f(x) = ax + b, di mana a adalah gradien (kemiringan) dan b adalah intersep y.'
        },
        // Perhitungan sederhana
        {
            id: 3,
            level: 'mudah',
            type: 'mc',
            question: 'Jika f(x) = x + 3, maka f(5) = ...',
            options: ['5', '8', '15', '3'],
            correct: 1,
            explanation: 'f(5) = 5 + 3 = 8'
        },
        {
            id: 4,
            level: 'mudah',
            type: 'mc',
            question: 'Jika g(x) = 4x + 5, maka g(2) = ...',
            options: ['8', '13', '10', '9'],
            correct: 1,
            explanation: 'g(2) = 4(2) + 5 = 8 + 5 = 13'
        },
        {
            id: 5,
            level: 'sedang',
            type: 'mc',
            question: 'Jika h(x) = 3x - 9, maka h(4) = ...',
            options: ['3', '12', '3', '15'],
            correct: 0,
            explanation: 'h(4) = 3(4) - 9 = 12 - 9 = 3'
        },
        // Komposisi
        {
            id: 6,
            level: 'sedang',
            type: 'mc',
            question: 'Diketahui f(x) = x + 3 dan g(x) = 4x + 5. Maka (f ∘ g)(x) = ...',
            options: [
                '4x + 8',
                '4x + 17',
                '4x + 5',
                'x + 8'
            ],
            correct: 0,
            explanation: '(f ∘ g)(x) = f(g(x)) = f(4x + 5) = (4x + 5) + 3 = 4x + 8'
        },
        {
            id: 7,
            level: 'sedang',
            type: 'mc',
            question: 'Diketahui f(x) = x + 3 dan g(x) = 4x + 5. Maka (g ∘ f)(x) = ...',
            options: [
                '4x + 8',
                '4x + 17',
                '4x + 5',
                'x + 17'
            ],
            correct: 1,
            explanation: '(g ∘ f)(x) = g(f(x)) = g(x + 3) = 4(x + 3) + 5 = 4x + 12 + 5 = 4x + 17'
        },
        {
            id: 8,
            level: 'sedang',
            type: 'mc',
            question: 'Diketahui f(x) = x + 3 dan h(x) = 3x - 9. Maka (h ∘ f)(x) = ...',
            options: [
                '3x',
                '3x - 6',
                '3x + 3',
                'x - 9'
            ],
            correct: 0,
            explanation: '(h ∘ f)(x) = h(f(x)) = h(x + 3) = 3(x + 3) - 9 = 3x + 9 - 9 = 3x'
        },
        {
            id: 9,
            level: 'sulit',
            type: 'mc',
            question: 'Diketahui f(x) = x + 3, g(x) = 4x + 5, h(x) = 3x - 9. Maka (f ∘ g ∘ h)(x) = ...',
            options: [
                '12x - 28',
                '12x - 31',
                '12x + 8',
                '4x - 28'
            ],
            correct: 0,
            explanation: 'h(x) = 3x-9 → g(h(x)) = 4(3x-9)+5 = 12x-36+5 = 12x-31 → f(g(h(x))) = (12x-31)+3 = 12x-28'
        },
        {
            id: 10,
            level: 'sulit',
            type: 'mc',
            question: 'Jika f(x) = x + 3 dan g(x) = 4x + 5, maka (f ∘ g)(2) = ...',
            options: ['16', '15', '13', '11'],
            correct: 0,
            explanation: 'g(2) = 4(2)+5 = 13 → f(13) = 13+3 = 16. Atau (f∘g)(x)=4x+8 → 4(2)+8=16'
        },
        {
            id: 11,
            level: 'sedang',
            type: 'mc',
            question: 'Grafik fungsi linear f(x) = ax + b akan naik (miring ke atas) jika...',
            options: [
                'a > 0',
                'a < 0',
                'b > 0',
                'b < 0'
            ],
            correct: 0,
            explanation: 'Koefisien a menentukan kemiringan. Jika a > 0, grafik naik; jika a < 0, grafik turun.'
        },
        {
            id: 12,
            level: 'mudah',
            type: 'mc',
            question: 'Domain dari fungsi f(x) = x + 3 adalah...',
            options: [
                'Semua bilangan real',
                'x ≥ 0',
                'x > 3',
                'x ≠ 0'
            ],
            correct: 0,
            explanation: 'Fungsi linear f(x) = x + 3 terdefinisi untuk semua bilangan real, sehingga domainnya adalah ℝ.'
        }
    ];

    let currentIndex = 0;
    let score = 0;
    let answered = [];
    let userAnswers = {};

    function init() {
        const startBtn = document.getElementById('ex-start');
        const nextBtn = document.getElementById('ex-next');
        const prevBtn = document.getElementById('ex-prev');
        const checkBtn = document.getElementById('ex-check');
        const restartBtn = document.getElementById('ex-restart');

        if (startBtn) startBtn.addEventListener('click', startExercise);
        if (nextBtn) nextBtn.addEventListener('click', nextQuestion);
        if (prevBtn) prevBtn.addEventListener('click', prevQuestion);
        if (checkBtn) checkBtn.addEventListener('click', checkAnswer);
        if (restartBtn) restartBtn.addEventListener('click', restart);

        // Level filter
        const levelFilter = document.getElementById('ex-level');
        if (levelFilter) levelFilter.addEventListener('change', filterByLevel);
    }

    function filterByLevel() {
        // Optional: could filter questions, but for simplicity we show all
    }

    function startExercise() {
        currentIndex = 0;
        score = 0;
        answered = [];
        userAnswers = {};
        document.getElementById('ex-intro').style.display = 'none';
        document.getElementById('ex-quiz').style.display = 'block';
        document.getElementById('ex-result').style.display = 'none';
        showQuestion();
        updateProgress();
    }

    function showQuestion() {
        const q = questions[currentIndex];
        const container = document.getElementById('ex-question-area');
        if (!container) return;

        let optionsHtml = q.options.map((opt, i) => `
            <label class="option ${userAnswers[q.id] === i ? 'selected' : ''} ${answered.includes(q.id) ? (i === q.correct ? 'correct' : (userAnswers[q.id] === i ? 'wrong' : '')) : ''}">
                <input type="radio" name="answer" value="${i}" ${userAnswers[q.id] === i ? 'checked' : ''} ${answered.includes(q.id) ? 'disabled' : ''}>
                <span class="option-text">${opt}</span>
            </label>
        `).join('');

        container.innerHTML = `
            <div class="question-header">
                <span class="q-number">Soal ${currentIndex + 1} dari ${questions.length}</span>
                <span class="q-level level-${q.level}">${q.level.toUpperCase()}</span>
            </div>
            <div class="question-text">${q.question}</div>
            <div class="options-list">${optionsHtml}</div>
            <div id="ex-explanation" class="explanation" style="display: none;"></div>
        `;

        // Add listeners to options
        container.querySelectorAll('input[name="answer"]').forEach(input => {
            input.addEventListener('change', (e) => {
                userAnswers[q.id] = parseInt(e.target.value);
                // Update UI selection
                container.querySelectorAll('.option').forEach(opt => opt.classList.remove('selected'));
                e.target.closest('.option').classList.add('selected');
            });
        });

        // Show explanation if already answered
        if (answered.includes(q.id)) {
            showExplanation(q);
        }

        updateNavButtons();
    }

    function checkAnswer() {
        const q = questions[currentIndex];
        if (userAnswers[q.id] === undefined) {
            alert('Pilih salah satu jawaban terlebih dahulu!');
            return;
        }
        if (answered.includes(q.id)) return;

        answered.push(q.id);
        if (userAnswers[q.id] === q.correct) {
            score++;
        }
        showExplanation(q);
        updateProgress();
        // Re-render to show correct/wrong
        showQuestion();
    }

    function showExplanation(q) {
        const expEl = document.getElementById('ex-explanation');
        if (expEl) {
            const isCorrect = userAnswers[q.id] === q.correct;
            expEl.style.display = 'block';
            expEl.className = 'explanation ' + (isCorrect ? 'correct-exp' : 'wrong-exp');
            expEl.innerHTML = `
                <strong>${isCorrect ? '✓ Benar!' : '✗ Salah'}</strong><br>
                ${q.explanation}
            `;
        }
    }

    function nextQuestion() {
        if (currentIndex < questions.length - 1) {
            currentIndex++;
            showQuestion();
        } else {
            showResult();
        }
    }

    function prevQuestion() {
        if (currentIndex > 0) {
            currentIndex--;
            showQuestion();
        }
    }

    function updateNavButtons() {
        const prevBtn = document.getElementById('ex-prev');
        const nextBtn = document.getElementById('ex-next');
        const checkBtn = document.getElementById('ex-check');

        if (prevBtn) prevBtn.disabled = currentIndex === 0;
        if (nextBtn) {
            nextBtn.textContent = currentIndex === questions.length - 1 ? 'Lihat Hasil' : 'Selanjutnya';
        }
        if (checkBtn) {
            checkBtn.style.display = answered.includes(questions[currentIndex].id) ? 'none' : 'inline-flex';
        }
    }

    function updateProgress() {
        const progressEl = document.getElementById('ex-progress');
        const scoreEl = document.getElementById('ex-score-live');
        if (progressEl) {
            const pct = (answered.length / questions.length) * 100;
            progressEl.style.width = pct + '%';
        }
        if (scoreEl) {
            scoreEl.textContent = `${score} / ${answered.length}`;
        }
    }

    function showResult() {
        document.getElementById('ex-quiz').style.display = 'none';
        document.getElementById('ex-result').style.display = 'block';
        
        const percentage = Math.round((score / questions.length) * 100);
        let message = '';
        if (percentage >= 80) message = 'Excellent! Kamu menguasai materi dengan baik.';
        else if (percentage >= 60) message = 'Bagus! Terus berlatih untuk hasil lebih baik.';
        else message = 'Jangan menyerah! Pelajari kembali materi dan coba lagi.';

        // Simpan skor ke sistem MathLearn (per akun)
        if (typeof window.MathLearnSaveScore === 'function') {
            window.MathLearnSaveScore(score, questions.length);
        }

        document.getElementById('ex-final-score').innerHTML = `
            <div class="score-circle">
                <span class="score-num">${score}</span>
                <span class="score-den">/ ${questions.length}</span>
            </div>
            <div class="score-pct">${percentage}%</div>
            <p class="score-msg">${message}</p>
        `;
    }

    function restart() {
        document.getElementById('ex-result').style.display = 'none';
        document.getElementById('ex-intro').style.display = 'block';
        document.getElementById('ex-quiz').style.display = 'none';
    }

    return { init, startExercise, questions };
})();

window.Exercises = Exercises;
