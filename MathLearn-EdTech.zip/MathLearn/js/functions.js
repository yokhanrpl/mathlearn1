/**
 * MathLearn - Core Math Functions
 * Fungsi matematika murni untuk perhitungan fungsi linear, kuadrat, dan komposisi
 */

// Definisi fungsi default dari papan tulis
const DEFAULT_FUNCTIONS = {
    f: {
        name: 'f',
        expression: 'x + 3',
        a: 1,
        b: 3,
        type: 'linear',
        compute: (x) => x + 3
    },
    g: {
        name: 'g',
        expression: '4x + 5',
        a: 4,
        b: 5,
        type: 'linear',
        compute: (x) => 4 * x + 5
    },
    h: {
        name: 'h',
        expression: '3x - 9',
        a: 3,
        b: -9,
        type: 'linear',
        compute: (x) => 3 * x - 9
    }
};

// Fungsi untuk membuat fungsi linear dinamis
function createLinear(a, b) {
    return {
        a: a,
        b: b,
        expression: formatLinearExpression(a, b),
        type: 'linear',
        compute: (x) => a * x + b
    };
}

// Fungsi untuk membuat fungsi kuadrat
function createQuadratic(a, b, c) {
    return {
        a: a,
        b: b,
        c: c,
        expression: formatQuadraticExpression(a, b, c),
        type: 'quadratic',
        compute: (x) => a * x * x + b * x + c
    };
}

// Format ekspresi linear
function formatLinearExpression(a, b) {
    let expr = '';
    if (a === 1) expr = 'x';
    else if (a === -1) expr = '-x';
    else if (a !== 0) expr = a + 'x';
    
    if (b > 0) {
        if (expr) expr += ' + ' + b;
        else expr = String(b);
    } else if (b < 0) {
        if (expr) expr += ' - ' + Math.abs(b);
        else expr = String(b);
    } else if (!expr) {
        expr = '0';
    }
    return expr;
}

// Format ekspresi kuadrat
function formatQuadraticExpression(a, b, c) {
    let parts = [];
    if (a === 1) parts.push('x²');
    else if (a === -1) parts.push('-x²');
    else if (a !== 0) parts.push(a + 'x²');
    
    if (b === 1) parts.push('+ x');
    else if (b === -1) parts.push('- x');
    else if (b > 0) parts.push('+ ' + b + 'x');
    else if (b < 0) parts.push('- ' + Math.abs(b) + 'x');
    
    if (c > 0) parts.push('+ ' + c);
    else if (c < 0) parts.push('- ' + Math.abs(c));
    
    let expr = parts.join(' ').replace(/^\+ /, '').trim();
    if (!expr) expr = '0';
    return expr;
}

// Komposisi dua fungsi: (outer ∘ inner)(x) = outer(inner(x))
function compose(outer, inner) {
    return {
        expression: `(${outer.name || 'f'} ∘ ${inner.name || 'g'})(x)`,
        compute: (x) => outer.compute(inner.compute(x)),
        steps: (x) => {
            const innerVal = inner.compute(x);
            const result = outer.compute(innerVal);
            return {
                innerExpr: `${inner.name || 'g'}(${x}) = ${innerVal}`,
                outerExpr: `${outer.name || 'f'}(${innerVal}) = ${result}`,
                result: result
            };
        },
        algebraic: composeAlgebraic(outer, inner)
    };
}

// Komposisi aljabar untuk linear
function composeAlgebraic(outer, inner) {
    if (outer.type === 'linear' && inner.type === 'linear') {
        // outer(inner(x)) = a_o * (a_i * x + b_i) + b_o = (a_o * a_i)x + (a_o * b_i + b_o)
        const a = outer.a * inner.a;
        const b = outer.a * inner.b + outer.b;
        return {
            a: a,
            b: b,
            expression: formatLinearExpression(a, b),
            steps: [
                `${outer.name || 'f'}(${inner.name || 'g'}(x)) = ${outer.name || 'f'}(${inner.expression})`,
                `= ${outer.a}(${inner.expression}) + ${outer.b}`,
                `= ${outer.a * inner.a}x + ${outer.a * inner.b} + ${outer.b}`,
                `= ${formatLinearExpression(a, b)}`
            ]
        };
    }
    return null;
}

// Komposisi tiga fungsi: outer(mid(inner(x)))
function composeThree(outer, mid, inner) {
    return {
        expression: `(${outer.name} ∘ ${mid.name} ∘ ${inner.name})(x)`,
        compute: (x) => outer.compute(mid.compute(inner.compute(x))),
        algebraic: (() => {
            // Pertama compose mid ∘ inner
            const midInner = composeAlgebraic(mid, inner);
            if (!midInner) return null;
            // Kemudian outer ∘ (mid∘inner)
            const result = composeAlgebraic(outer, { a: midInner.a, b: midInner.b, type: 'linear', name: `(${mid.name}∘${inner.name})` });
            return result;
        })()
    };
}

// Evaluasi aman tanpa eval - parser sederhana untuk ekspresi linear/kuadrat
function parseAndEvaluate(expr, x) {
    // Hanya dukung bentuk sederhana: ax^2 + bx + c atau ax + b
    // Untuk keamanan, kita gunakan fungsi yang sudah didefinisikan
    // Atau parse manual
    try {
        // Ganti x dengan nilai
        let safeExpr = expr
            .replace(/\s+/g, '')
            .replace(/x²/g, `(${x})*(${x})`)
            .replace(/x\^2/g, `(${x})*(${x})`)
            .replace(/x/g, `(${x})`);
        
        // Validasi karakter yang diizinkan
        if (!/^[0-9+\-*/().]+$/.test(safeExpr)) {
            throw new Error('Ekspresi tidak valid');
        }
        
        // Gunakan Function constructor sebagai alternatif aman (masih terbatas)
        // Tapi lebih baik hitung manual
        return Function('"use strict"; return (' + safeExpr + ')')();
    } catch (e) {
        return null;
    }
}

// Hitung nilai fungsi dari koefisien
function evaluateLinear(a, b, x) {
    return a * x + b;
}

function evaluateQuadratic(a, b, c, x) {
    return a * x * x + b * x + c;
}

// Generate data untuk grafik
function generateGraphData(computeFn, xMin = -10, xMax = 10, steps = 100) {
    const data = [];
    const step = (xMax - xMin) / steps;
    for (let i = 0; i <= steps; i++) {
        const x = xMin + i * step;
        const y = computeFn(x);
        if (isFinite(y) && Math.abs(y) < 1e6) { // Hindari nilai ekstrem
            data.push({ x: parseFloat(x.toFixed(4)), y: parseFloat(y.toFixed(4)) });
        }
    }
    return data;
}

// Export untuk digunakan di modul lain
window.MathFunctions = {
    DEFAULT_FUNCTIONS,
    createLinear,
    createQuadratic,
    compose,
    composeThree,
    composeAlgebraic,
    evaluateLinear,
    evaluateQuadratic,
    generateGraphData,
    formatLinearExpression,
    formatQuadraticExpression,
    parseAndEvaluate
};
