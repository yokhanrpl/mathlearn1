# MathLearn — Platform EdTech Fungsi Matematika

Website pembelajaran interaktif tentang **fungsi, grafik fungsi, dan komposisi fungsi** untuk siswa SMK, dengan area terpisah bagi **Siswa**, **Guru**, dan **Admin**.

## Fitur

### Siswa
- Dashboard progres belajar
- Materi: Pengenalan Fungsi, Linear, Kuadrat, Komposisi
- Contoh soal per materi
- Grafik fungsi interaktif (Chart.js)
- Kalkulator fungsi & komposisi (2 & 3 fungsi)
- Latihan soal + skor + pembahasan
- Profil & reset progress

### Guru
- Dashboard ringkasan siswa & skor
- Tabel progres siswa
- Laporan hasil latihan
- Akses materi & alat praktik

### Admin
- Dashboard jumlah akun per role
- Kelola pengguna (ubah role, aktif/nonaktif)
- Laporan nilai siswa
- **Password tidak pernah ditampilkan**

## Design System
- Background `#F4F4F2`, surface putih, sidebar `#252525`
- Aksen kuning `#F5C542`
- Dark mode tersedia

## Teknologi
- HTML5, CSS3, Vanilla JavaScript
- Chart.js (CDN)
- Penyimpanan: **localStorage** (bukan database server)

## Akun Demo
| Role   | Username | Password |
|--------|----------|----------|
| Siswa  | `siswa`  | `12345`  |
| Guru   | `guru`   | `12345`  |
| Admin  | `admin`  | `12345`  |

Registrasi publik hanya membuat akun **siswa**.

## Cara Menjalankan
1. Ekstrak ZIP
2. Buka folder `MathLearn` di VS Code
3. Install ekstensi **Live Server**
4. Klik kanan `index.html` → **Open with Live Server**

Atau buka `index.html` langsung di browser.

## Struktur Folder
```
MathLearn/
├── index.html
├── css/style.css
├── js/
│   ├── app.js          # Auth, role, dashboard, navigasi
│   ├── functions.js    # Utilitas matematika
│   ├── calculator.js
│   ├── graph.js
│   └── exercises.js
├── assets/
└── README.md
```

## Keterbatasan Keamanan
Ini adalah **prototype frontend**. Autentikasi dan role disimpan di browser.  
Siapa pun dapat mengubah localStorage. **Tidak aman untuk produksi** tanpa backend.

## Fungsi Matematika Default
- f(x) = x + 3  
- g(x) = 4x + 5  
- h(x) = 3x − 9  

Komposisi diverifikasi (contoh: (f∘g)(x) = 4x+8, (g∘f)(x) = 4x+17).
